#!/usr/local/bin/python2.7

dsn = {
'passwd': 'sybase',
'host': 'localhost',
'db': 'eventscal_db',
'user': 'webdb'}
